#!/bin/bash

for (( counter=5; counter>0; counter-- ))

do

echo  "$counter "

done

printf "\n"
#enes