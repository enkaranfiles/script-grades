#!/bin/bash

for (( counter=3; counter>0; counter-- ))

do

echo  "$counter "

done

printf "\n"
#enes
#ayça
#atakan
